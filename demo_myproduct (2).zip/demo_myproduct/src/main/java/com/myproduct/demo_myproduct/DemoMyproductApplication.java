package com.myproduct.demo_myproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMyproductApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMyproductApplication.class, args);
	}

}
